import 'package:flutter/material.dart';

class Favourite with ChangeNotifier {
  List items_ = [];
  List get favouriteItems => items_;

  void addToFavourite(cartItem) {
    final isExist = items_.contains(cartItem);
    if (isExist) {
      items_.remove(cartItem);
    } else {
      items_.add(cartItem);
    }
    notifyListeners();
  }

  bool isExist(cartItem) {
    final isExist = items_.contains(cartItem);
    return isExist;
  }
}
