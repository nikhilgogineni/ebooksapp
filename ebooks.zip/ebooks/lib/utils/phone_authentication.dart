import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

final phoneAuth = PhoneAuthentication();

class PhoneAuthentication {
  FirebaseAuth auth = FirebaseAuth.instance;

  TextEditingController phoneController = TextEditingController();
  String verificationID = '';
  String smsCode = '';
  sendVerificationCode() async {
    try {
      await auth.verifyPhoneNumber(
        phoneNumber: phoneController.text,
        verificationCompleted: (phoneAuthCredential) {},
        verificationFailed: (FirebaseException e) {
          if (kDebugMode) {
            print(e.message);
          }
        },
        codeSent: (String verificationId, int? forceResendingToken) {
          verificationID = verificationId;
        },
        codeAutoRetrievalTimeout: (verificationId) {
          verificationID = verificationId;
        },
      );
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
    }
  }

  signInWithCredential() async {
    try {
      PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: verificationID,
        smsCode: smsCode,
      );
      await auth.signInWithCredential(credential);
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
    }
  }
}
