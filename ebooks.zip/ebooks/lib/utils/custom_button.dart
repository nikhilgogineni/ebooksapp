import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  final Color color1;
  final Color color2;
  final String textName;
  const CustomButton(
      {Key? key,
      required this.textName,
      required this.color1,
      required this.color2})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: color1,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Center(
          child: Padding(
        padding: const EdgeInsets.all(20),
        child: Text(
          textName,
          style: TextStyle(
            color: color2,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      )),
    );
  }
}
