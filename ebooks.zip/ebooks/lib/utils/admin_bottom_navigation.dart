import 'package:ebooks/view/admin_account_view.dart';
import 'package:ebooks/view/admin_home_view.dart';
import 'package:flutter/material.dart';
import 'package:ebooks/constants/custom_colors.dart';
import 'package:ebooks/constants/strings.dart';
import 'package:ebooks/constants/custom_icon.dart';

// ignore: must_be_immutable
class AdminBottomNavigationWidget extends StatefulWidget {
  int selectedIndex;
  AdminBottomNavigationWidget({Key? key, required this.selectedIndex})
      : super(key: key);

  @override
  State<AdminBottomNavigationWidget> createState() =>
      _AdminBottomNavigationWidgetState();
}

class _AdminBottomNavigationWidgetState
    extends State<AdminBottomNavigationWidget> {
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      onTap: (index) {
        widget.selectedIndex = index;
        if (index == 0) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const AdminHomeView(),
              ),
              (route) => false);
        } else if (index == 1) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const AdminAccountView(),
              ),
              (route) => false);
        }
      },
      type: BottomNavigationBarType.fixed,
      selectedItemColor: customColors.blue,
      unselectedItemColor: customColors.black,
      currentIndex: widget.selectedIndex,
      items: [
        BottomNavigationBarItem(
          icon: customIcon.home,
          label: strings.home,
        ),
        BottomNavigationBarItem(
          icon: customIcon.username,
          label: strings.account,
        ),
      ],
    );
  }
}
