import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

final databaseReference = DatabaseReference();

class DatabaseReference {
  final reference = FirebaseDatabase.instance.ref("books");

  FirebaseAuth auth = FirebaseAuth.instance;
  final referenceUsers = FirebaseDatabase.instance.ref("users");
}
