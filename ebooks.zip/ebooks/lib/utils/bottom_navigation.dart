import 'package:ebooks/view/account_view.dart';
import 'package:ebooks/view/download_view.dart';
import 'package:ebooks/view/explore_view.dart';
import 'package:ebooks/view/favorite_view.dart';
import 'package:ebooks/view/user_home_view.dart';
import 'package:flutter/material.dart';
import 'package:ebooks/constants/custom_colors.dart';
import 'package:ebooks/constants/strings.dart';
import 'package:ebooks/constants/custom_icon.dart';

// ignore: must_be_immutable
class BottomNavigationWidget extends StatefulWidget {
  int selectedIndex;
  BottomNavigationWidget({Key? key, required this.selectedIndex})
      : super(key: key);

  @override
  State<BottomNavigationWidget> createState() => _BottomNavigationWidgetState();
}

class _BottomNavigationWidgetState extends State<BottomNavigationWidget> {
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      onTap: (index) {
        widget.selectedIndex = index;
        if (index == 0) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const UserHomeView(),
              ),
              (route) => false);
        } else if (index == 1) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const ExploreView(),
              ),
              (route) => false);
        } else if (index == 2) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const DownloadView(),
              ),
              (route) => false);
        } else if (index == 3) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const FavoriteView(),
              ),
              (route) => false);
        } else if (index == 4) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const AccountView(),
              ),
              (route) => false);
        }
      },
      type: BottomNavigationBarType.fixed,
      selectedItemColor: customColors.blue,
      unselectedItemColor: customColors.black,
      currentIndex: widget.selectedIndex,
      items: [
        BottomNavigationBarItem(
          icon: customIcon.home,
          label: strings.home,
        ),
        BottomNavigationBarItem(
          icon: customIcon.search,
          label: strings.explore,
        ),
        BottomNavigationBarItem(
          icon: customIcon.download,
          label: strings.download,
        ),
        BottomNavigationBarItem(
          icon: customIcon.favorite,
          label: strings.favorite,
        ),
        BottomNavigationBarItem(
          icon: customIcon.username,
          label: strings.account,
        ),
      ],
    );
  }
}
