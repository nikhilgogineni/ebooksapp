import 'package:ebooks/utils/custom_button.dart';
import 'package:ebooks/view/intro_page.dart';
import 'package:ebooks/view/user_home_view.dart';
import 'package:flutter/material.dart';
import 'package:ebooks/constants/custom_colors.dart';
import 'package:ebooks/constants/strings.dart';
import 'package:ebooks/utils/phone_authentication.dart';

class UserVerify extends StatefulWidget {
  const UserVerify({Key? key}) : super(key: key);

  @override
  State<UserVerify> createState() => _UserVerifyState();
}

class _UserVerifyState extends State<UserVerify> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: customColors.blue,
      appBar: AppBar(backgroundColor: customColors.transparent),
      body: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Container(
            padding: const EdgeInsets.all(30),
            decoration: BoxDecoration(
              color: customColors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Form(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Text(
                      strings.userVerify,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: TextFormField(
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        hintText: strings.phone,
                        border: const OutlineInputBorder(),
                      ),
                      onChanged: (value) {
                        setState(() {
                          phoneAuth.smsCode = value;
                        });
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: InkWell(
                      onTap: () {
                        phoneAuth.signInWithCredential();
                        Navigator.of(context).pushAndRemoveUntil(
                            MaterialPageRoute(
                              builder: (context) => const UserHomeView(),
                            ),
                            (route) => false);
                      },
                      child: CustomButton(
                        textName: strings.login,
                        color1: customColors.blue,
                        color2: customColors.white,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(
                            builder: (context) => const IntroPage(),
                          ),
                          (route) => false);
                    },
                    child: Text(
                      strings.back,
                      style: TextStyle(
                        color: customColors.blue,
                        fontSize: 20,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
