import 'package:ebooks/utils/custom_button.dart';
import 'package:ebooks/view/intro_page.dart';
import 'package:ebooks/view_model/user_login_view_model.dart';
import 'package:ebooks/view/user_verify.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:ebooks/constants/custom_colors.dart';
import 'package:ebooks/constants/strings.dart';
import 'package:ebooks/utils/phone_authentication.dart';

class UserLogin extends StatefulWidget {
  const UserLogin({Key? key}) : super(key: key);

  @override
  State<UserLogin> createState() => _UserLoginState();
}

class _UserLoginState extends State<UserLogin> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<UserLoginViewModel>.reactive(
      viewModelBuilder: () => UserLoginViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        backgroundColor: customColors.blue,
        appBar: AppBar(backgroundColor: customColors.transparent),
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Container(
              padding: const EdgeInsets.all(30),
              decoration: BoxDecoration(
                color: customColors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Form(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Text(
                        strings.userLogin,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(
                        controller: phoneAuth.phoneController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          hintText: strings.phone,
                          border: const OutlineInputBorder(),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: InkWell(
                        onTap: () {
                          phoneAuth.sendVerificationCode();
                          Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(
                                builder: (context) => const UserVerify(),
                              ),
                              (route) => false);
                        },
                        child: CustomButton(
                          textName: strings.enterOtp,
                          color1: customColors.blue,
                          color2: customColors.white,
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pushAndRemoveUntil(
                            MaterialPageRoute(
                              builder: (context) => const IntroPage(),
                            ),
                            (route) => false);
                      },
                      child: Text(
                        strings.back,
                        style: TextStyle(
                          color: customColors.blue,
                          fontSize: 20,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
