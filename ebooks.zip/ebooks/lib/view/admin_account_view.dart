import 'package:ebooks/utils/admin_bottom_navigation.dart';
import 'package:ebooks/utils/database_reference.dart';
import 'package:ebooks/view_model/admin_account_view_model.dart';
import 'package:ebooks/utils/custom_button.dart';
import 'package:ebooks/constants/custom_colors.dart';
import 'package:ebooks/view/intro_page.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:ebooks/constants/strings.dart';
import 'package:ebooks/constants/custom_icon.dart';

class AdminAccountView extends StatefulWidget {
  const AdminAccountView({Key? key}) : super(key: key);

  @override
  State<AdminAccountView> createState() => _AdminAccountViewState();
}

class _AdminAccountViewState extends State<AdminAccountView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<AdminAccountViewModel>.reactive(
      viewModelBuilder: () => AdminAccountViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          title: Text(strings.profile),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              FirebaseAnimatedList(
                shrinkWrap: true,
                query: databaseReference.reference,
                itemBuilder: (context, snapshot, animation, index) {
                  final username = snapshot.child("username").value.toString();
                  final email = snapshot.child("email").value.toString();
                  final password = snapshot.child("password").value.toString();
                  return Visibility(
                    visible: snapshot.child("uid").value ==
                        databaseReference.auth.currentUser!.uid,
                    child: Column(
                      children: [
                        ListTile(
                          leading: customIcon.username,
                          title: const Text("Name:"),
                          subtitle: Text(username),
                          trailing: IconButton(
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text("Edit username: "),
                                  content: TextFormField(
                                    controller: viewModel.usernameController,
                                    decoration: const InputDecoration(
                                      hintText: "Edit username",
                                      border: OutlineInputBorder(),
                                    ),
                                  ),
                                  actions: [
                                    ElevatedButton(
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                        child: const Text("Cancel")),
                                    ElevatedButton(
                                        onPressed: () {
                                          viewModel.updateName();
                                        },
                                        child: const Text("update")),
                                  ],
                                ),
                              );
                            },
                            icon: customIcon.edit,
                          ),
                        ),
                        ListTile(
                          leading: customIcon.email,
                          title: const Text("Email:"),
                          subtitle: Text(email),
                          trailing: IconButton(
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text("Edit email: "),
                                  content: TextFormField(
                                    controller: viewModel.usernameController,
                                    decoration: const InputDecoration(
                                      hintText: "Edit email",
                                      border: OutlineInputBorder(),
                                    ),
                                  ),
                                  actions: [
                                    ElevatedButton(
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                        child: const Text("Cancel")),
                                    ElevatedButton(
                                        onPressed: () {
                                          viewModel.updateEmail(email);
                                        },
                                        child: const Text("update")),
                                  ],
                                ),
                              );
                            },
                            icon: customIcon.edit,
                          ),
                        ),
                        ListTile(
                          leading: customIcon.password,
                          title: const Text("Password:"),
                          subtitle: Text(password),
                          trailing: IconButton(
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text("Edit password: "),
                                  content: TextFormField(
                                    controller: viewModel.usernameController,
                                    decoration: const InputDecoration(
                                      hintText: "Edit password",
                                      border: OutlineInputBorder(),
                                    ),
                                  ),
                                  actions: [
                                    ElevatedButton(
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                        child: const Text("Cancel")),
                                    ElevatedButton(
                                        onPressed: () {
                                          viewModel.updatePassword();
                                        },
                                        child: const Text("update")),
                                  ],
                                ),
                              );
                            },
                            icon: customIcon.edit,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(20),
                          child: InkWell(
                            onTap: () {
                              viewModel.signOut();
                              Navigator.of(context).pushAndRemoveUntil(
                                  MaterialPageRoute(
                                    builder: (context) => const IntroPage(),
                                  ),
                                  (route) => false);
                            },
                            child: CustomButton(
                              textName: strings.signOut,
                              color1: customColors.blue,
                              color2: customColors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              )
            ],
          ),
        ),
        bottomNavigationBar:
            AdminBottomNavigationWidget(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
