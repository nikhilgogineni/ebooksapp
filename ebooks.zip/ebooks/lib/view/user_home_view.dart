import 'package:ebooks/utils/bottom_navigation.dart';
import 'package:ebooks/constants/custom_colors.dart';
import 'package:ebooks/utils/database_reference.dart';
import 'package:ebooks/view_model/user_home_view_model.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

class UserHomeView extends StatefulWidget {
  const UserHomeView({Key? key}) : super(key: key);

  @override
  State<UserHomeView> createState() => _UserHomeViewState();
}

class _UserHomeViewState extends State<UserHomeView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<UserHomeViewModel>.reactive(
      viewModelBuilder: () => UserHomeViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          backgroundColor: customColors.white,
          title: const Text("Dashboard"),
          centerTitle: true,
        ),
        body: StreamBuilder(
            stream: databaseReference.reference.onValue,
            builder: (context, AsyncSnapshot<DatabaseEvent> snapshot2) {
              if (snapshot2.hasData) {
                Map<dynamic, dynamic> data =
                    snapshot2.data!.snapshot.value as dynamic;
                List<dynamic> list = [];
                list.clear();
                list = data.values.toList();

                return GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.75,
                  ),
                  itemCount: snapshot2.data!.snapshot.children.length,
                  itemBuilder: (context, index) {
                    final cartItem = list[index];
                    final image = cartItem["imageURL"];
                    final book = cartItem["book"];
                    final author = cartItem["author"];
                    final category = cartItem["category"];

                    return SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      physics: const AlwaysScrollableScrollPhysics(),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                              border: Border.all(),
                              borderRadius: BorderRadius.circular(20)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Center(
                                child: Image.network(
                                  image,
                                  height: 90,
                                  width: 90,
                                ),
                              ),
                              Text(book),
                              Text(author),
                              Text(category),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              } else {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }
            }),
        bottomNavigationBar:
            BottomNavigationWidget(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
