import 'package:ebooks/view/admin_login.dart';
import 'package:ebooks/view_model/admin_register_view_model.dart';
import 'package:ebooks/utils/custom_button.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:ebooks/constants/custom_colors.dart';
import 'package:ebooks/constants/strings.dart';

class AdminRegister extends StatefulWidget {
  const AdminRegister({Key? key}) : super(key: key);

  @override
  State<AdminRegister> createState() => _AdminRegisterState();
}

class _AdminRegisterState extends State<AdminRegister> {
  @override
  Widget build(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    return ViewModelBuilder<AdminRegisterViewModel>.reactive(
      viewModelBuilder: () => AdminRegisterViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        backgroundColor: customColors.blue,
        appBar: AppBar(backgroundColor: customColors.transparent),
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Container(
              padding: const EdgeInsets.all(30),
              decoration: BoxDecoration(
                color: customColors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Form(
                key: formKey,
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Text(
                        strings.adminRegister,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(
                        controller: viewModel.usernameController,
                        decoration: InputDecoration(
                          hintText: strings.username,
                          border: const OutlineInputBorder(),
                        ),
                        validator: (name) {
                          if (name == null || name.isEmpty) {
                            return "Enter username";
                          } else {
                            return null;
                          }
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(
                        controller: viewModel.emailController,
                        decoration: InputDecoration(
                          hintText: strings.email,
                          border: const OutlineInputBorder(),
                        ),
                        validator: (email) {
                          if (email == null || email.isEmpty) {
                            return "Enter email";
                          } else if (!RegExp(
                                  r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                              .hasMatch(email)) {
                            return "Invalid password";
                          } else {
                            return null;
                          }
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(
                        controller: viewModel.passwordController,
                        decoration: InputDecoration(
                          hintText: strings.password,
                          border: const OutlineInputBorder(),
                        ),
                        validator: (password) {
                          if (password == null || password.isEmpty) {
                            return "Enter password";
                          } else if (!RegExp(
                                  r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$')
                              .hasMatch(password)) {
                            return "Invalid password";
                          } else {
                            return null;
                          }
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: InkWell(
                        onTap: () async {
                          if (formKey.currentState!.validate()) {
                            try {
                              await viewModel.register();
                              // ignore: use_build_context_synchronously
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text("registered successfully"),
                                  showCloseIcon: true,
                                ),
                              );
                            } on FirebaseAuthException catch (e) {
                              if (e.code == "email-already-in-use") {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text("email already in use"),
                                    showCloseIcon: true,
                                  ),
                                );
                              }
                            }
                          }
                        },
                        child: CustomButton(
                          textName: strings.signUp,
                          color1: customColors.blue,
                          color2: customColors.white,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            strings.alreadyHaveAccount,
                            style: const TextStyle(fontSize: 16),
                          ),
                          InkWell(
                            onTap: () {
                              Navigator.of(context).pushAndRemoveUntil(
                                  MaterialPageRoute(
                                    builder: (context) => const AdminLogin(),
                                  ),
                                  (route) => false);
                            },
                            child: Text(
                              strings.signIn,
                              style: TextStyle(
                                color: customColors.blue,
                                fontSize: 16,
                              ),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
