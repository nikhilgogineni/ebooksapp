import 'package:ebooks/view_model/account_view_model.dart';
import 'package:ebooks/utils/bottom_navigation.dart';
import 'package:ebooks/utils/custom_button.dart';
import 'package:ebooks/constants/custom_colors.dart';
import 'package:ebooks/view/intro_page.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:ebooks/constants/strings.dart';
import 'package:ebooks/constants/custom_icon.dart';

class AccountView extends StatefulWidget {
  const AccountView({Key? key}) : super(key: key);

  @override
  State<AccountView> createState() => _AccountViewState();
}

class _AccountViewState extends State<AccountView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<AccountViewModel>.reactive(
      viewModelBuilder: () => AccountViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          title: Text(strings.profile),
          centerTitle: true,
        ),
        body: Column(
          children: [
            ListTile(
              leading: customIcon.phone,
              title: Text(strings.phoneNumber),
              subtitle: Text(strings.number),
              trailing: IconButton(
                onPressed: () {},
                icon: customIcon.edit,
              ),
            ),
            const SizedBox(
              height: 350,
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: InkWell(
                onTap: () {
                  // viewModel.signOut();
                  Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(
                        builder: (context) => const IntroPage(),
                      ),
                      (route) => false);
                },
                child: CustomButton(
                  textName: strings.signOut,
                  color1: customColors.blue,
                  color2: customColors.white,
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar:
            BottomNavigationWidget(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
