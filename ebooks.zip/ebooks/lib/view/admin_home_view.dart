import 'package:ebooks/utils/admin_bottom_navigation.dart';
import 'package:ebooks/view/add_task_view.dart';
import 'package:ebooks/view_model/admin_home_view_model.dart';
import 'package:ebooks/constants/custom_colors.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:ebooks/utils/database_reference.dart';
import 'package:ebooks/constants/strings.dart';

class AdminHomeView extends StatefulWidget {
  const AdminHomeView({Key? key}) : super(key: key);

  @override
  State<AdminHomeView> createState() => _AdminHomeViewState();
}

class _AdminHomeViewState extends State<AdminHomeView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<AdminHomeViewModel>.reactive(
      viewModelBuilder: () => AdminHomeViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => const AddBookView(),
            ));
          },
          child: const Icon(Icons.add),
        ),
        appBar: AppBar(
          backgroundColor: customColors.white,
          title: const Text("Dashboard"),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(strings.programming),
              FirebaseAnimatedList(
                shrinkWrap: true,
                query: databaseReference.reference,
                itemBuilder: (context, snapshot, animation, index) {
                  final book = snapshot.child("book").value.toString();
                  final author = snapshot.child("author").value.toString();
                  final image = snapshot.child("imageURL").value.toString();
                  final category = snapshot.child("category").value.toString();

                  if (category == strings.programming) {
                    return Card(
                      child: ListTile(
                        leading: Image.network(image, height: 40, width: 40),
                        title: Text("Name of the Book: $book"),
                        subtitle: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("author: $author"),
                            Text("category: $category"),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return Container();
                  }
                },
              ),
              Text(strings.spiritual),
              FirebaseAnimatedList(
                shrinkWrap: true,
                query: databaseReference.reference,
                itemBuilder: (context, snapshot, animation, index) {
                  final book = snapshot.child("book").value.toString();
                  final author = snapshot.child("author").value.toString();
                  final image = snapshot.child("imageURL").value.toString();
                  final category = snapshot.child("category").value.toString();

                  if (category == strings.spiritual) {
                    return Card(
                      child: ListTile(
                        leading: Image.network(image, height: 40, width: 40),
                        title: Text("Name of the Book: $book"),
                        subtitle: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("author: $author"),
                            Text("category: $category"),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return Container();
                  }
                },
              ),
              Text(strings.fiction),
              FirebaseAnimatedList(
                shrinkWrap: true,
                query: databaseReference.reference,
                itemBuilder: (context, snapshot, animation, index) {
                  final book = snapshot.child("book").value.toString();
                  final author = snapshot.child("author").value.toString();
                  final image = snapshot.child("imageURL").value.toString();
                  final category = snapshot.child("category").value.toString();

                  if (category == strings.fiction) {
                    return Card(
                      child: ListTile(
                        leading: Image.network(image, height: 40, width: 40),
                        title: Text("Name of the Book: $book"),
                        subtitle: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("author: $author"),
                            Text("category: $category"),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return Container();
                  }
                },
              ),
              Text(strings.horror),
              FirebaseAnimatedList(
                shrinkWrap: true,
                query: databaseReference.reference,
                itemBuilder: (context, snapshot, animation, index) {
                  final book = snapshot.child("book").value.toString();
                  final author = snapshot.child("author").value.toString();
                  final image = snapshot.child("imageURL").value.toString();
                  final category = snapshot.child("category").value.toString();

                  if (category == strings.horror) {
                    return Card(
                      child: ListTile(
                        leading: Image.network(image, height: 40, width: 40),
                        title: Text("Name of the Book: $book"),
                        subtitle: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("author: $author"),
                            Text("category: $category"),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return Container();
                  }
                },
              ),
            ],
          ),
        ),
        bottomNavigationBar:
            AdminBottomNavigationWidget(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
