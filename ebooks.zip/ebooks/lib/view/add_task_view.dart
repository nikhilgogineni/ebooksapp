import 'package:ebooks/constants/custom_colors.dart';
import 'package:ebooks/view_model/add_task_view_model.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:ebooks/utils/custom_button.dart';

class AddBookView extends StatefulWidget {
  const AddBookView({Key? key}) : super(key: key);

  @override
  State<AddBookView> createState() => _AddBookViewState();
}

class _AddBookViewState extends State<AddBookView> {
  @override
  Widget build(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    return ViewModelBuilder<AddBookViewModel>.reactive(
      viewModelBuilder: () => AddBookViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          title: const Text("Add Book"),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Form(
            key: formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: viewModel.bookNameController,
                  decoration: const InputDecoration(
                    hintText: "Book Name",
                    border: OutlineInputBorder(),
                  ),
                  validator: (book) {
                    if (book == null || book.isEmpty) {
                      return "Enter book name";
                    } else {
                      return null;
                    }
                  },
                ),
                TextFormField(
                  controller: viewModel.authorController,
                  decoration: const InputDecoration(
                    hintText: "Author name",
                    border: OutlineInputBorder(),
                  ),
                  validator: (author) {
                    if (author == null || author.isEmpty) {
                      return "Enter author name";
                    } else {
                      return null;
                    }
                  },
                ),
                TextFormField(
                  controller: viewModel.categoryController,
                  decoration: const InputDecoration(
                    hintText: "category",
                    border: OutlineInputBorder(),
                  ),
                  validator: (category) {
                    if (category == null || category.isEmpty) {
                      return "Enter category";
                    } else {
                      return null;
                    }
                  },
                ),
                ElevatedButton(
                    onPressed: () {
                      setState(() {
                        viewModel.selectImageFile();
                      });
                    },
                    child: const Text("select image")),
                ElevatedButton(
                    onPressed: () {
                      setState(() {
                        viewModel.selectPdfFile();
                      });
                    },
                    child: const Text("upload pdf")),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: InkWell(
                    onTap: () {
                      if (formKey.currentState!.validate()) {
                        viewModel.addBooks();
                      }
                    },
                    child: CustomButton(
                      textName: "Add Book",
                      color1: customColors.blue,
                      color2: customColors.white,
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
