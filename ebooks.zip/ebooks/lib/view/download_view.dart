import 'package:ebooks/utils/bottom_navigation.dart';
import 'package:ebooks/constants/custom_colors.dart';
import 'package:ebooks/view_model/download_view_model.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

class DownloadView extends StatefulWidget {
  const DownloadView({Key? key}) : super(key: key);

  @override
  State<DownloadView> createState() => _DownloadViewState();
}

class _DownloadViewState extends State<DownloadView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<DownloadViewModel>.reactive(
      viewModelBuilder: () => DownloadViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          backgroundColor: customColors.white,
          title: const Text("Downloads"),
          centerTitle: true,
        ),
        bottomNavigationBar:
            BottomNavigationWidget(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
