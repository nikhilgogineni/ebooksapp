import 'package:ebooks/utils/bottom_navigation.dart';
import 'package:ebooks/utils/database_reference.dart';
import 'package:ebooks/view_model/favorite_view_model.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';
import 'package:ebooks/utils/favorite.dart';

class FavoriteView extends StatefulWidget {
  const FavoriteView({Key? key}) : super(key: key);

  @override
  State<FavoriteView> createState() => _FavoriteViewState();
}

class _FavoriteViewState extends State<FavoriteView> {
  @override
  Widget build(BuildContext context) {
    final providerFav = Provider.of<Favourite>(context);
    return ViewModelBuilder<FavoriteViewModel>.reactive(
      viewModelBuilder: () => FavoriteViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          title: const Text("Favorites"),
          centerTitle: true,
        ),
        body: FirebaseAnimatedList(
          query: databaseReference.reference,
          itemBuilder: (context, snapshot, animation, index) {
            final cartItem = snapshot;
            final book = cartItem.child("book").value.toString();
            final author = cartItem.child("author").value.toString();
            final image = cartItem.child("imageURL").value.toString();

            return Card(
              child: ListTile(
                leading: Image.network(image),
                title: Text(book),
                subtitle: Text(author),
                trailing: IconButton(
                    onPressed: () {
                      providerFav.addToFavourite(cartItem);
                    },
                    icon: const Icon(Icons.delete)),
              ),
            );
          },
        ),
        bottomNavigationBar:
            BottomNavigationWidget(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
