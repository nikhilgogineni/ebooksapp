import 'package:flutter/material.dart';
import '../../constants/custom_colors.dart';

// ignore: must_be_immutable
class BookDetailsView extends StatefulWidget {
  String book;
  String image;
  String author;
  VoidCallback? onPressed;
  Icon icon;
  BookDetailsView(
      {Key? key,
      required this.book,
      required this.image,
      required this.author,
      this.onPressed,
      required this.icon})
      : super(key: key);

  @override
  State<BookDetailsView> createState() => _BookDetailsViewState();
}

class _BookDetailsViewState extends State<BookDetailsView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColors.backgroundWhite,
      ),
      body: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: customColors.backgroundWhite,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(25),
                bottomRight: Radius.circular(25),
              ),
            ),
            child: Center(
              child: ClipRect(
                child: Image.network(
                  widget.image,
                  height: 250,
                  width: 250,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  widget.book,
                  style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                IconButton(onPressed: widget.onPressed, icon: widget.icon),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Text(
                  widget.author,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Container(
              decoration: BoxDecoration(
                color: customColors.blue,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Text(
                    "Download",
                    style: TextStyle(
                      color: customColors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
