import 'package:ebooks/utils/favorite.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ebooks/utils/database_reference.dart';
import 'package:ebooks/constants/custom_colors.dart';
import 'package:ebooks/view/book_details_widget.dart';
import 'package:ebooks/constants/strings.dart';

class SpiritualView extends StatefulWidget {
  const SpiritualView({Key? key}) : super(key: key);

  @override
  State<SpiritualView> createState() => _SpiritualViewState();
}

class _SpiritualViewState extends State<SpiritualView> {
  @override
  Widget build(BuildContext context) {
    final providerFav = Provider.of<Favourite>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(strings.spiritual),
        centerTitle: true,
      ),
      body: FirebaseAnimatedList(
        shrinkWrap: true,
        query: databaseReference.reference,
        itemBuilder: (context, snapshot, animation, index) {
          final cartItem = snapshot;
          final book = cartItem.child("book").value.toString();
          final author = cartItem.child("author").value.toString();
          final image = cartItem.child("imageURL").value.toString();
          final category = cartItem.child("category").value.toString();

          if (category == strings.spiritual) {
            return Card(
              child: ListTile(
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => BookDetailsView(
                      image: image,
                      author: author,
                      book: book,
                      onPressed: () => providerFav.addToFavourite(cartItem),
                      icon: providerFav.isExist(cartItem)
                          ? Icon(
                              Icons.favorite,
                              color: customColors.blueGrey,
                            )
                          : const Icon(
                              Icons.favorite_border,
                            ),
                    ),
                  ));
                },
                leading: Image.network(image, height: 40, width: 40),
                title: Text("Name of the Book: $book"),
                subtitle: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("author: $author"),
                    Text("category: $category"),
                  ],
                ),
              ),
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }
}
