import 'package:flutter/material.dart';
import 'package:ebooks/utils/database_reference.dart';

class AdminAccountViewModel extends ChangeNotifier {
  int selectedIndex = 1;

  TextEditingController usernameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  updateName() {
    databaseReference.reference
        .child(databaseReference.auth.currentUser!.uid)
        .update({
      "username": usernameController.text,
    });
  }

  updateEmail(String email) {
    databaseReference.auth.currentUser!.updateEmail(email);
    databaseReference.reference
        .child(databaseReference.auth.currentUser!.uid)
        .update({
      "email": emailController.text,
    });
  }

  updatePassword() {
    databaseReference.reference
        .child(databaseReference.auth.currentUser!.uid)
        .update({
      "password": passwordController.text,
    });
  }

  signOut() async {
    await databaseReference.auth.signOut();
  }
}
