import 'package:flutter/material.dart';

class ExploreViewModel extends ChangeNotifier {
  int selectedIndex = 1;
}
