import 'package:flutter/material.dart';
import 'package:ebooks/utils/database_reference.dart';

class AdminLoginViewModel extends ChangeNotifier {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  signIn() async {
    await databaseReference.auth.signInWithEmailAndPassword(
        email: emailController.text, password: passwordController.text);
  }
}
