import 'package:flutter/material.dart';

class UserLoginViewModel extends ChangeNotifier {
  TextEditingController phoneController = TextEditingController();
}
