import 'package:flutter/material.dart';
import 'package:ebooks/utils/database_reference.dart';

class AccountViewModel extends ChangeNotifier {
  int selectedIndex = 4;

  signOut() async {
    await databaseReference.auth.signOut();
  }
}
