import 'package:flutter/material.dart';

class UserHomeViewModel extends ChangeNotifier {
  int selectedIndex = 0;
}
