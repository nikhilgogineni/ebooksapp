import 'package:flutter/material.dart';
import 'package:ebooks/utils/database_reference.dart';

class AdminRegisterViewModel extends ChangeNotifier {
  TextEditingController usernameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  register() async {
    await databaseReference.auth.createUserWithEmailAndPassword(
        email: emailController.text, password: passwordController.text);
    String uid = databaseReference.auth.currentUser!.uid;
    String id = DateTime.now().millisecondsSinceEpoch.toString();
    databaseReference.referenceUsers
        .child(databaseReference.auth.currentUser!.uid)
        .set(
      {
        "username": usernameController.text.toString(),
        "email": emailController.text.toString(),
        "password": passwordController.text.toString(),
        "uid": uid.toString(),
        "id": id.toString(),
      },
    );
  }
}
