import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:file_picker/file_picker.dart';
import 'package:ebooks/utils/database_reference.dart';

class AddBookViewModel extends ChangeNotifier {
  TextEditingController bookNameController = TextEditingController();
  TextEditingController authorController = TextEditingController();
  TextEditingController categoryController = TextEditingController();

  FirebaseFirestore fs = FirebaseFirestore.instance;

  PlatformFile? pickedImageFile;
  PlatformFile? pickedPdfFile;
  UploadTask? imageUploadTask;
  UploadTask? pdfUploadTask;
  String? imageURL;
  Future selectImageFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null) return;
    pickedImageFile = result.files.first;
  }

  Future selectPdfFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null) return;
    pickedPdfFile = result.files.first;
  }

  addBooks() async {
    final imagePath = 'images/${pickedImageFile!.name}';
    final imageFile = File(pickedImageFile!.path!);

    final ref = FirebaseStorage.instance.ref().child(imagePath);
    imageUploadTask = ref.putFile(imageFile);

    final snapshot1 = await imageUploadTask!.whenComplete(() {});
    final urlDownload = await snapshot1.ref.getDownloadURL();

    final pdfPath = 'pdf/${pickedPdfFile!.name}';
    final pdfFile = File(pickedPdfFile!.path!);

    final pdfRef = FirebaseStorage.instance.ref().child(pdfPath);
    pdfUploadTask = pdfRef.putFile(pdfFile);

    final snapshot2 = await pdfUploadTask!.whenComplete(() {});
    final pdfUrlDownload = await snapshot2.ref.getDownloadURL();

    await fs.collection("pdfs").add({
      "book": bookNameController.text,
      "pdfUrl": pdfUrlDownload,
    });

    String id = DateTime.now().millisecondsSinceEpoch.toString();
    databaseReference.reference.child(id).set({
      "book": bookNameController.text,
      "author": authorController.text,
      "category": categoryController.text,
      "imageURL": urlDownload,
    });
  }
}
