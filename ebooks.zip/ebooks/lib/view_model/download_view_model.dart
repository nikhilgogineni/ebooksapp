import 'package:flutter/material.dart';

class DownloadViewModel extends ChangeNotifier {
  int selectedIndex = 2;
}
