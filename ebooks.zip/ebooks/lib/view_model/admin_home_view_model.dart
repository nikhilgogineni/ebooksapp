import 'package:flutter/material.dart';

class AdminHomeViewModel extends ChangeNotifier {
  int selectedIndex = 0;
}
