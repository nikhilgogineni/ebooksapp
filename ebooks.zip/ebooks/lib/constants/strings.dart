final strings = Strings();

class Strings {
  /// intro page
  final String eBooks = "E Books";
  final String user = "User";
  final String admin = "Admin";

  /// admin login
  final String adminLogin = "Admin Login";
  final String email = "email";
  final String password = "password";
  final String login = "Login";
  final String noAccount = "Don't have an account? ";
  final String signUp = "Sign Up";
  final String back = "Back";

  /// admin register
  final String adminRegister = "Admin Register";
  final String username = "username";
  final String alreadyHaveAccount = "Already have an Account? ";
  final String signIn = "Sign in";

  /// user login
  final String userLogin = "User Login";
  final String phone = "phone";
  final String enterOtp = "Enter OTP";

  /// user verify
  final String userVerify = "User Verify";

  /// bottom navigation
  final String home = "Home";
  final String explore = "Explore";
  final String download = "Download";
  final String favorite = "Favorite";
  final String account = "Account";

  /// user account
  final String profile = "Profile";
  final String phoneNumber = "Phone Number";
  final String number = "123456789";
  final String signOut = "Sign out";

  /// category strings
  final String programming = "programming";
  final String fiction = "fiction";
  final String spiritual = "spiritual";
  final String horror = "horror";
}
