import 'package:flutter/material.dart';

final customIcon = CustomIcon();

class CustomIcon {
  final Icon username = const Icon(Icons.person_outline);
  final Icon email = const Icon(Icons.email);
  final Icon phone = const Icon(Icons.phone);
  final Icon password = const Icon(Icons.password);
  final Icon edit = const Icon(Icons.edit);
  final Icon home = const Icon(Icons.home);
  final Icon search = const Icon(Icons.search);
  final Icon favorite = const Icon(Icons.favorite_border);
  final Icon download = const Icon(Icons.download);
}
