import 'package:flutter/material.dart';

final customColors = CustomColors();

class CustomColors {
  final Color white = Colors.white;
  final Color blue = Colors.blue;
  final Color black = Colors.black;
  final Color transparent = Colors.transparent;
  final Color backgroundWhite = const Color(0xFFf2f3f2);
  final Color blueGrey = Colors.blueGrey;
}
