package com.example.ebooks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
